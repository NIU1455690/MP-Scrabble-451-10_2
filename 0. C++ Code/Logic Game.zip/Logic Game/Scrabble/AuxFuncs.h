#include "../GraphicManager.h"

#ifndef AuxFuncs_h
#define AuxFuncs_h

IMAGE_NAME letterToImageName(char letter, bool big);

#endif // !AuxFuncs_h

